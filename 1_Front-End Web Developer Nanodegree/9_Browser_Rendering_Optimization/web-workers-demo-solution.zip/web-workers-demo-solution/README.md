# Web Workers Demo

### [Relevant Quiz from Browser Rendering Optimization](https://www.udacity.com/course/viewer#!/c-ud860/l-4138168623/e-4184098558/m-4150829139)

### [Relevant solution from Browser Rendering Optimization](https://www.udacity.com/course/viewer#!/c-ud860/l-4138168623/e-4184098558/m-4146278980)

There are two versions of the solution here: index-solution.html and index-solution-improved.html. index-solution-improved.html includes the big bug fix, but index-solution.html does not.